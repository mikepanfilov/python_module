def has_digits(password):
  return any(symbol.isdigit() for symbol in password)

def has_letters(password):
  return any(symbol.isalpha() for symbol in password)

def has_upper_letters(password):
  return any(symbol.isupper() for symbol in password)

def has_lower_letters(password):
  return any(symbol.islower() for symbol in password)

def has_symbols(password):
  return any(not symbol.isalnum() for symbol in password)

def doesnt_consist_of_symbols(password):
  return not(all(not symbol.isalnum() for symbol in password))

def is_very_long(password):
  return len(password) > 12

func_list = [has_digits, is_very_long, has_letters,has_upper_letters, has_lower_letters, has_symbols,doesnt_consist_of_symbols]

# password = input('Введите пароль: ')

checklist = [
"rnfeinginr",
"rnvnreiv83282",
"onrv",
"ogvorneorenvoernb",
"grg129",
"1297129",
"GnoiIGIrg129",
"12971eorin29",
"grg129",
"1297129",
"OFNRON@2379",
"onregn04",
"OVN#O2049)@$we",
"ow131f2FFE",
"@#(&&(@&$(@"
]

for pswd in checklist:
  score = 0
  for func in func_list:
    if func(pswd):
      score+=2
  print(pswd,':',score)